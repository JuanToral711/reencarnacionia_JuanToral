<!------ Verificar si hay token ---------->
<?php 
if(empty($_GET['token'])){
   header("Location: login.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<link rel="stylesheet" href="../assets/css/estilologin.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!------ Include the above in your HEAD tag ---------->


<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


<body style="background:#8fc3ff;">
    <div class="container">
        <div class="row">
			<div class="col-md-5 mx-auto">
			<div id="first">
				<div class="myform form ">
					 <div class="logo mb-3">
						 <div class="col-md-12 text-center">
                      <div class="form-group"><img width="100%" src="../assets/img/newcontrasena.jpg"></div>
							<h1>Nueva Contraseña</h1>
                     
						 </div>
					</div>
                     <?php
                      include ("../assets/funciones_php/database.php");
                      $token = $_GET['token'];
                      $bd = new ConectionServer();
                      $conn = $bd->getConnection();

                      $sql = "SELECT * FROM usuarios WHERE token='$token'";
                      $resultado = mysqli_query($conn, $sql);
                      $contador = mysqli_num_rows($resultado);
                      if ($contador == 1 ) {
                        $fila = mysqli_fetch_array($resultado, MYSQLI_ASSOC);
                        $uid = $fila['uid'];
                        echo '
                        <h3 align="center"> Bienvenido '.$fila['nombre'].'</h3>
                        <div class="login-or">
                        <form method="post">
                        <input type="hidden" name="id" value="'.$uid.'" id="uid"></input>
                        <div class="form-group" style="margin: 10px;">
                           <label for="password">Nueva Contraseña</label>
                           <input  type="password" name="password" id="new_password" for="password"  autocomplete="on"  class="form-control" aria-describedby="emailHelp" placeholder="Ingresa Nueva Contraseña" required>
                        </div>
                        <br>
                        <div class="form-group">
                           <p class="text-center">Escribe tu una nueva contraseña para tu cuenta.</p>
                        </div>
                        <div class="col-md-12 text-center ">
                           <button name="new_pass"  value="" id="new_pass" class=" btn btn-block mybtn btn-primary tx-tfm">Guardar Contraseña</button>
                        </div>
                        <br>
                        <div class="form-group">
                           <span style="margin-top:5px;" id="respuesta"></span>
                        </div>
                     </form>';
                      } else {
                         echo '<h3 style="text-align: center; color:red;"> Ha ocurrido un error: URL no valida, pagina no disponible.</h3>';
                         echo '<br><h6 style="text-align: center; color:blue;"><a href="login.php">Ir a Inicio de Sesion de "InfoRobot".</a></h6>';
                      }
                      mysqli_close($conn);
                      ?>
				</div>
         
			</div>
			  <div id="second">
			      <div class="myform form ">
                        <div class="logo mb-3">
                           <div class="col-md-12 text-center">
                              <h1 >Signup</h1>
                           </div>
                        </div>
                     </div>
			</div>
		</div>
      </div> 
      <script src="../assets/js/jquery3.js"></script>
      <script src="../assets/js/admin_login.js"></script>


        
</body>
</html>

