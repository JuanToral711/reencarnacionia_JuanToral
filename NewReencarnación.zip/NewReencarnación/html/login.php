<!DOCTYPE html>
<html lang="en">

<link rel="stylesheet" href="../assets/css/estilologin.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<!------ Include the above in your HEAD tag ---------->


<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


<body style="background:#8fc3ff;">
    <div class="container">
        <div class="row">
			<div class="col-md-5 mx-auto">
			<div id="first">
				<div class="myform form ">
					 <div class="logo mb-3">
						 <div class="col-md-12 text-center">
                   <div class="form-group"><img width="50%" src="../assets/img/robovid.png"></div>
							<h1>Iniciar Sesión</h1>
						 </div>
					</div>
                   <form method="post">
                           <div class="form-group">
                              <label for="floatingInput">Correo Electronico</label>
                              <input type="correo" name="correo"  class="form-control" id="email" for="floatingInput" autocomplete="on" aria-describedby="emailHelp" placeholder="Ingresa Email" required>
                           </div>
                           <div class="form-group">
                              <label for="floatingPassword">Contraseña</label>
                              <input  type="password" name="password" id="password" for="floatingPassword"  autocomplete="on"  class="form-control" aria-describedby="emailHelp" placeholder="Ingresa Contraseña" required>
                           </div>
                           <div class="form-group">
                           <span style="margin-top:10px;" id="respuesta"></span>
                           </div>
                           <div class="col-md-12 text-center ">
                              <button  value="Iniciar" id="login" class=" btn btn-block mybtn btn-primary tx-tfm">Iniciar</button>
                           </div>
                           <div class="col-md-12 ">
                              <div class="login-or">
                                 <hr class="hr-or">
                                 <span class="span-or">o</span>
                              </div>
                           </div>
                           <div class="form-group">
                              <p class="text-center">Olvidaste tu Contrseña? <a href="recuperar.php" id="signup">Haz Click Aqui!</a></p>
                           </div>
                           <div class="form-group">
                              <h6 class="text-center">Al usar nuestro sitio aceptas nuestros Términos y Condiciones de uso</h6>
                           </div>  
                        </form>
				</div>
         
			</div>
			  <div id="second">
			      <div class="myform form ">
                        <div class="logo mb-3">
                           <div class="col-md-12 text-center">
                              <h1 >Signup</h1>
                           </div>
                        </div>
                     </div>
			</div>
		</div>
      </div> 
      <script src="../assets/js/jquery3.js"></script>
      <script src="../assets/js/admin_login.js"></script>


        
</body>
</html>

