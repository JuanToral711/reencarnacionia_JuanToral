<?php
   $conn = mysqli_connect("localhost","root","","inforobot");
   $conn->set_charset('utf8_spanish2_ci');


?>