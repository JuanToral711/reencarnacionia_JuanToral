<?php 
if(empty($_POST['new_password']) || empty($_POST['id'])){
    header("Location: ../../html/login.php");
}
    include ("database.php");
    $bd = new ConectionServer();
    $conn = $bd->getConnection();

    $nueva = md5(strip_tags($_POST['new_password']));
    $id = $_POST['id'];

    $sql = "UPDATE usuarios SET password ='$nueva', token = '' WHERE uid=$id";
    $resultado = mysqli_query($conn, $sql);
    $contador = mysqli_num_rows($resultado);
    if($resultado==true){
        echo "Correcto";
    }
    mysqli_close($conn);
?>