<?php
session_start();
$_SESSION['login_user'] = '';
$_SESSION['type_user'] = '';
$_COOKIE['token'] = '';
$_SESSION['token'] = '';
setcookie('token', '', time()-1, "/");
session_destroy();
header("Location: ../../html/index.html");

?>