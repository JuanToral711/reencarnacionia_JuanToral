
<?php
    include_once 'database.php';
    include_once 'PHPMailer.php';
    include_once 'SMTP.php';
    
    session_start();
    if(isset($_POST['email'])) {
        $server = new ConectionServer();
        $conexion = $server->getConnection();
        $correo = strip_tags($_POST['email']);
        $sql = "SELECT * FROM usuarios where email ='$correo'";
        $result = mysqli_query($conexion, $sql);
        $contar = mysqli_num_rows($result);
        
        if ($contar == 1) {
            $datos = mysqli_fetch_array($result, MYSQLI_ASSOC);
            //Creacion del Token
            $id = $datos ["uid"];
            $nombre = $datos ["nombre"];
            $apellidos = $datos ["apellidos"];
            $token = base64_encode(sha1(uniqid(rand(),true)));

            //Create an instance; passing `true` enables exceptions
            $mail = new PHPMailer(true);

            try {
                $actualizar = "UPDATE usuarios SET token = '$token' WHERE email='$correo'";
                $resultado = mysqli_query($conexion, $actualizar);
                //Server settings
                $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                $mail->isSMTP();                                            //Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                $mail->Username   = 'pjupueba@gmail.com';                     //SMTP username
                $mail->Password   = 'jupueba3001@';                               //SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                //Recipients
                $mail->setFrom('pjupueba@gmail.com', 'InfoRobot');
                $mail->addAddress($correo, $nombre);     //Add a recipient
                //$mail->addAddress('ellen@example.com');               //Name is optional
                //$mail->addReplyTo('info@example.com', 'Information');
                //$mail->addCC('cc@example.com');
                //$mail->addBCC('bcc@example.com');

                //Attachments
                //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
                //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

                //Content
                $mail->isHTML(true);                                  //Set email format to HTML
                $mail->Subject = 'RECUPERAR CONTRASEÑA EN --INFOROBOT--';
                $mail->Body    = '<h3> Para recuperar debes seguir las indicaciones:</h3> <ul><li>Dale Click al enlace: <b><a href="http://localhost:8000/NewReencarnaci%C3%B3n/html/nuevacontrasena.php?token='.$token.'">Aqui!!!</a></b></ul></li>';
                $mail->AltBody = 'Este en un correo de InfoRobot para la recuperacion de tu contraseña';

                $mail->send();
                echo 'Message has been sent';
                alert('Revisa tu Correo.');
            }catch(Exception $e){
            }
            //Fin Creacion del Token


            
            $server->closeConnection();
        }else{
            echo 'ERROR: No se envio ningun correo, Intentalo mas Tarde.';
        }
    }
?>
