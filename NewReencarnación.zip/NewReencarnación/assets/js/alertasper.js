Swal.fire(
    "Bienvenido a InfoRobot",
     "Aqui podras ver y interactuar con variedad de información sobre la Inteligencia Artificial, Evolucion, Reencarnacion, etc... Espero y te Guste :)",
     "info"
);