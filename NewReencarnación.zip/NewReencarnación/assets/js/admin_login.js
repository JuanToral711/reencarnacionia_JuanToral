$(document).ready(()=>{
//Iniciar Sesion
    $('#login').click((e)=>{
        e.preventDefault();
        let email = $("#email").val();
        let password = $("#password").val();
        let datos = 'email=' +email+ '&password=' + password;
        if ($.trim(email).length > 0 && $.trim(password).length > 0)  {
            $.ajax({
                type: "POST",
                url: "../assets/funciones_php/logina.php",
                data : datos,
                beforeSend: () => {
                    $('#respuesta').html('<span style="color:red;"> Cargando... </span>')
                },
                success: (dates) => {
                    if(dates){
                    $("#respuesta").html(
                        '<span style="color:green;"> Correcto, Redirigiendo... </span>'
                    );
                    setTimeout(() => {
                        window.location.href = '../html/index.html';
                    },2000);
                    }else{
                        $("#respuesta").html(
                            '<span style="color:red;">Email o Contraseña Incorrecto. </span>'
                        );
                        setTimeout(()=>{
                            $("#respuesta").html('');
                        },4000);
                    }
                }
            });

        }else{
            alert ("TIENES QUE COMPLETAR TODOS LOS CAMPOS");
        }
    });
});

//Recuperar contraseña
$('#send_email').click((e)=>{
    e.preventDefault();
    let email = $("#email").val();
    let datos = 'email=' + email;
    if ($.trim(email).length > 0)  {
        $.ajax({
            type: "POST",
            url: "../assets/funciones_php/recuperara.php",
            data : datos,
            beforeSend: () => {
                $('#respuesta').html('<span style="color:red;"> Enviando Correo... </span>')
            },
            success: (dates) => {
                if(dates){
                $("#respuesta").html(
                    '<span style="color:green;"> Correcto: Correo Enviado, Revisa tu Correo. </span>'
                );
                setTimeout(() => {
                    window.location.href = '../html/login.php';
                },2000);
                }else{
                    $("#respuesta").html(
                        '<span style="color:red;">Email Incorrecto o no existente. </span>'
                    );
                    setTimeout(()=>{
                        $("#respuesta").html('');
                    },4000);
                }
            }
        });

    }else{
        alert ("TIENES QUE COMPLETAR TODOS LOS CAMPOS");
    }
});

//Nueva Contraseña
$('#new_pass').click((e)=>{
    e.preventDefault();
    let id = $("#uid").val();
    let pass = $("#new_password").val();

    let datos = 'new_password=' + pass +'&id='+id;
    if ($.trim(pass).length > 0)  {
        $.ajax({
            type: "POST",
            url: "../assets/funciones_php/save_new_pass.php",
            data : datos,
            beforeSend: () => {
                $('#respuesta').html('<span style="color:red;"> Guardando Nueva Contraseña... </span>')
            },
            success: (dates) => {
                if(dates){
                $("#respuesta").html(
                    '<span style="color:green;"> Correcto: Tu contraseña ha sido guardada correctamente. Redirigiendo... </span>'
                );
                setTimeout(() => {
                    window.location.href = '../html/login.php';
                },2000);
                }else{
                    $("#respuesta").html(
                        '<span style="color:red;">ERROR: No se guardo la contraseña, Intentalo mas Tarde. </span>'
                    );
                    setTimeout(()=>{
                        $("#respuesta").html('');
                    },4000);
                }
            }
        });

    }else{
        alert ("TIENES QUE COMPLETAR TODOS LOS CAMPOS");
    }
});






