Swal.fire({
    imageUrl:'../assets/img/opinionc.jpg',
    title: 'Tu Opinion nos Importa',
    text: 'No olives dejarnos un comentario en nuestro apartado Contacto.',
    footer:'<a class="btn-reply" href="../comenta/index.php"> «Más info»</a>',
    width:'300px',
    height:'200px',
    showCloseButton: true,
    closeButtonArialLabel: 'Cerrar Anuncio',
    showConfirmButton: false,
    position: 'bottom-end',
    backdrop: false

});